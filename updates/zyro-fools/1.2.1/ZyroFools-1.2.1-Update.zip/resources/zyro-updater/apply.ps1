﻿param([ValidateSet('Apply','Confirm','Rollback')][string]$Action='Apply',[string]$Archive='',[string]$Envelope='',[string]$Target='', [switch]$Headless,[switch]$NoRestart)
$ErrorActionPreference='Stop'
if(-not $Target){$Target=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Programs\ZyroFools'}
$Target=[IO.Path]::GetFullPath($Target).TrimEnd([IO.Path]::DirectorySeparatorChar)
$work=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ZyroFools\Updater'
$journalFile=Join-Path $work 'pending.json';$rollback=Join-Path $work 'rollback';$stage=Join-Path $work 'stage';$log=Join-Path $work 'update.log';$script:applying=$false;$script:window=$null;$mutex=$null
function Safe-Path([string]$p){$q=$p;while(-not(Test-Path -LiteralPath $q)){$q=Split-Path -Parent $q;if(-not $q){throw 'Caminho inválido.'}};$item=Get-Item -LiteralPath $q -Force;while($item){if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Links não são permitidos na atualização.'};$item=$item.Parent}}
function Relative-Safe([string]$p){if(-not $p -or $p.Contains('\') -or $p.Contains(':') -or [IO.Path]::IsPathRooted($p) -or $p -match '(^|/)\.\.?(/|$)'){throw 'Arquivo fora do painel.'};if($p -notin @('ZyroFools.exe','LICENSE.electron.txt','LICENSES.chromium.html','LEIA-ME.md','chrome_100_percent.pak','chrome_200_percent.pak','d3dcompiler_47.dll','ffmpeg.dll','icudtl.dat','libEGL.dll','libGLESv2.dll','resources.pak','snapshot_blob.bin','v8_context_snapshot.bin','vk_swiftshader.dll','vk_swiftshader_icd.json','vulkan-1.dll','resources/app.asar','resources/app.asar.unpacked/guard-dpapi.ps1','resources/app.asar.unpacked/guard-migrate.ps1') -and -not $p.StartsWith('resources/zyro-updater/') -and -not $p.StartsWith('resources/core/') -and $p -notmatch '^locales/[A-Za-z-]+\.pak$'){throw 'Este pacote contém arquivos que não pertencem ao painel.'}}
function Log([string]$s){Add-Content -LiteralPath $log -Value ((Get-Date -Format 'yyyy-MM-dd HH:mm:ss')+' ['+$Action+'] '+$s) -Encoding UTF8}
function Pump {if($script:window){$script:window.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background)}}
function Status([string]$s,[int]$n){Log $s;if($script:window){$script:label.Text=$s;$script:label.ToolTip=$s;$script:bar.Value=$n;Pump}}
function Write-Journal($j){$tmp=$journalFile+'.tmp';$j|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $tmp -Encoding UTF8;Move-Item -LiteralPath $tmp -Destination $journalFile -Force}
function Runtime {return (Join-Path $Target 'ZyroFools.exe')}
function Run-Verify([string[]]$VerificationArgs){$out=Join-Path $work 'verified.json';if(Test-Path $out){Remove-Item $out};$old=$env:ELECTRON_RUN_AS_NODE;try{$env:ELECTRON_RUN_AS_NODE='1';& (Runtime) (Join-Path $PSScriptRoot 'verify.cjs') @VerificationArgs $out;if($LASTEXITCODE -ne 0){throw 'A verificação da atualização falhou.'};return(Get-Content $out -Raw|ConvertFrom-Json)}finally{$env:ELECTRON_RUN_AS_NODE=$old;if(Test-Path $out){Remove-Item $out}}}
function Stop-Panel {
 if($env:OS -ne 'Windows_NT'){return}
 $roots=@($Target)
 $programs=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'Programs'
 foreach($name in @('ZyroFools.update-backup','ZyroFools.update-stage')){$folder=Join-Path $programs $name;if(Test-Path $folder){try{Safe-Path $folder;$roots+=,$folder}catch{Log ('Processos do caminho redirecionado foram ignorados: '+$folder)}}}
 if(Test-Path $programs){foreach($folder in Get-ChildItem $programs -Directory -Force){if($folder.Name -match '^ZyroFools\.backup-preserved-[a-f0-9]{32}$'){try{Safe-Path $folder.FullName;$roots+=,$folder.FullName}catch{}}}}
 $recovery=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'ZyroFools\Recovery'
 if(Test-Path $recovery){try{Safe-Path $recovery;foreach($folder in Get-ChildItem $recovery -Directory -Force){if($folder.Name -match '^[a-f0-9]{32}$'){try{Safe-Path $folder.FullName;$roots+=,$folder.FullName}catch{}}}}catch{}}
 foreach($p in Get-CimInstance -ClassName Win32_Process){$file=[string]$p.ExecutablePath;if(-not $file){continue};$owned=$false;foreach($root in $roots){$main=[IO.Path]::GetDirectoryName($file) -ieq $root -and [IO.Path]::GetFileName($file) -in @('ZyroFools.exe','ZyroGuard.exe','ZyroGuard-new.exe');$core=$file.StartsWith((Join-Path $root 'resources\core')+'\',[StringComparison]::OrdinalIgnoreCase);if($main -or $core){$owned=$true;break}};if($owned){$process=Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue;if($process){try{Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop}catch{if(-not $process.HasExited){throw}};$process.WaitForExit(10000)|Out-Null;if(-not $process.HasExited){throw 'O painel ainda está em uso.'}}}}
}
function Swap-File([string]$source,[string]$dest){Safe-Path $source;Safe-Path $dest;New-Item -ItemType Directory -Path (Split-Path $dest) -Force|Out-Null;$stamp=[Guid]::NewGuid().ToString('N');$temp=$dest+'.zyro-new-'+$stamp;$oldTemp=$dest+'.zyro-old-'+$stamp;try{[IO.File]::Copy($source,$temp,$false);for($i=0;$i -lt 25;$i++){try{if(Test-Path -LiteralPath $dest){[IO.File]::Replace($temp,$dest,$oldTemp)}else{[IO.File]::Move($temp,$dest)};return}catch{if($i -eq 24){throw};Start-Sleep -Milliseconds 200;Pump}}}finally{if(Test-Path -LiteralPath $temp){Remove-Item -LiteralPath $temp -Force};if(Test-Path -LiteralPath $oldTemp){Remove-Item -LiteralPath $oldTemp -Force}}}
function Read-Journal {Safe-Path $journalFile;$j=Get-Content -LiteralPath $journalFile -Raw|ConvertFrom-Json;if($j.schema -ne 1 -or $j.target -ne $Target -or $j.files.Count -lt 1){throw 'Recuperação inválida.'};foreach($f in $j.files){Relative-Safe $f.path};return $j}
function Lock-Update {
 if($script:mutex){return}
 if($env:OS -eq 'Windows_NT'){for($i=0;$i -lt 120;$i++){$created=$false;$candidate=[Threading.Mutex]::new($false,'Local\ZyroFoolsDirectUpdate',[ref]$created);if($created){$script:mutex=$candidate;return};$candidate.Dispose();Start-Sleep -Milliseconds 250;Pump};throw 'Outra atualização está em andamento.'}
}
function Restore {
 Lock-Update
 $j=Read-Journal;Stop-Panel
 foreach($f in $j.files){$dest=Join-Path $Target $f.path;Safe-Path $dest;if($f.had){$saved=Join-Path $rollback $f.path;Safe-Path $saved;if((Get-FileHash $saved).Hash -ine $f.oldHash){throw 'Backup não passou na verificação.'};Swap-File $saved $dest}else{if(Test-Path -LiteralPath $dest){if((Get-FileHash $dest).Hash -ine $f.sha256){throw 'Arquivo novo foi alterado; recuperação interrompida.'};Remove-Item -LiteralPath $dest -Force}}}
 Remove-Item $journalFile -Force;Remove-Item $rollback -Recurse -Force;if(Test-Path $stage){Remove-Item $stage -Recurse -Force};Status 'Versão anterior restaurada.' 0
}
function Restart-Panel {if(-not $NoRestart){$oldNodeMode=$env:ELECTRON_RUN_AS_NODE;try{$env:ELECTRON_RUN_AS_NODE=$null;Start-Process -FilePath (Join-Path $Target 'ZyroFools.exe') -WorkingDirectory $Target}finally{$env:ELECTRON_RUN_AS_NODE=$oldNodeMode}}}
function Apply {
 if(Test-Path $journalFile){throw 'Há uma atualização aguardando confirmação. Abra o painel ou restaure a versão anterior.'}
 if((Test-Path $rollback) -and @(Get-ChildItem $rollback -Force).Count){throw 'Há um backup anterior que precisa ser recuperado.'}
 Status 'Autenticando a atualização…' 10
 $verified=Run-Verify -VerificationArgs @($Archive,$Envelope,$Target)
 Status ('Versão '+$verified.current+' → '+$verified.version) 20
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 if(Test-Path $stage){$marker=Join-Path $stage '.zyro-direct-stage';if(-not(Test-Path $marker) -or (Get-Content $marker -Raw).Trim() -ne 'zyro-direct-stage-v1'){throw 'Pasta temporária não reconhecida.'};Remove-Item $stage -Recurse -Force};New-Item -ItemType Directory -Path $stage -Force|Out-Null;Set-Content (Join-Path $stage '.zyro-direct-stage') 'zyro-direct-stage-v1'
 $zip=[IO.Compression.ZipFile]::OpenRead($Archive)
 try{$total=0;$seen=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase);foreach($entry in $zip.Entries){$name=$entry.FullName;if($name.EndsWith('/')){continue};if($name -ne 'update-files.json'){Relative-Safe $name};if(-not $seen.Add($name)){throw 'Arquivo duplicado no pacote.'};if($seen.Count -gt 10000){throw 'Muitos arquivos no pacote.'};$total+=$entry.Length;if($total -gt 1536MB -or $entry.Length -lt 0){throw 'Pacote grande demais.'};if((($entry.ExternalAttributes -shr 16) -band 0xF000) -eq 0xA000){throw 'Links no pacote não são permitidos.'};$file=Join-Path $stage $name;New-Item -ItemType Directory -Path (Split-Path $file) -Force|Out-Null;[IO.Compression.ZipFileExtensions]::ExtractToFile($entry,$file,$false)}}finally{$zip.Dispose()}
 $inventory=Get-Content (Join-Path $stage 'update-files.json') -Raw|ConvertFrom-Json
 if($inventory.schema -ne 1 -or $inventory.version -ne $verified.version -or $inventory.files.Count -lt 2){throw 'Inventário inválido.'}
 $list=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 foreach($f in $inventory.files){Relative-Safe $f.path;if(-not $list.Add($f.path)){throw 'Inventário duplicado.'};$file=Join-Path $stage $f.path;if(-not(Test-Path $file -PathType Leaf) -or (Get-FileHash $file).Hash -ine $f.sha256){throw 'Arquivo incompleto: '+$f.path}}
 if($seen.Count -ne $list.Count+1 -or -not $list.Contains('resources/app.asar')){throw 'Conteúdo inesperado no pacote.'}
 $rechecked=Run-Verify -VerificationArgs @($Archive,$Envelope,$Target);if($rechecked.version -ne $verified.version){throw 'O pacote mudou durante a verificação.'}
 Status 'Encerrando o painel e o Guard…' 35;Stop-Panel
 New-Item -ItemType Directory -Path $rollback -Force|Out-Null
 $records=@();foreach($f in $inventory.files){$dest=Join-Path $Target $f.path;Safe-Path $dest;$had=Test-Path $dest -PathType Leaf;$oldHash='';if($had){$saved=Join-Path $rollback $f.path;New-Item -ItemType Directory -Path (Split-Path $saved) -Force|Out-Null;[IO.File]::Copy($dest,$saved,$false);$oldHash=(Get-FileHash $saved).Hash};$records+=@{path=$f.path;had=$had;oldHash=$oldHash;sha256=$f.sha256}}
 $journal=@{schema=1;target=$Target;version=$verified.version;archive=$Archive;envelope=$Envelope;files=@($records)};Write-Journal $journal
 try{$n=0;foreach($f in $inventory.files){Swap-File (Join-Path $stage $f.path) (Join-Path $Target $f.path);if((Get-FileHash (Join-Path $Target $f.path)).Hash -ine $f.sha256){throw 'O arquivo aplicado não passou na verificação.'};$n++;Status ('Atualizando '+$n+' de '+$inventory.files.Count+' arquivos…') (40+[int](50*$n/$inventory.files.Count))}}
 catch{Log $_.Exception.Message;Restore;Restart-Panel;throw 'Não foi possível atualizar. A versão anterior foi restaurada.'}
 Status 'Atualização aplicada. Abrindo o Zyro Fools…' 100
 if($mutex){$mutex.Dispose();$script:mutex=$null};Restart-Panel
}
function Confirm {
 if(-not(Test-Path $journalFile)){return};$j=Read-Journal;$v=Run-Verify -VerificationArgs @('--version',$Target)
 if($v.version -ne $j.version){throw 'A versão aberta não corresponde à atualização.'}
 foreach($f in $j.files){$dest=Join-Path $Target $f.path;Safe-Path $dest;if((Get-FileHash $dest).Hash -ine $f.sha256){throw 'A atualização foi alterada antes de confirmar.'}}
 Safe-Path $rollback;Safe-Path $stage
 if(Test-Path $rollback){Remove-Item $rollback -Recurse -Force};if(Test-Path $stage){Remove-Item $stage -Recurse -Force}
 $bootstrap=Join-Path $work 'bootstrap'
 foreach($file in @($j.archive,$j.envelope)){if((Split-Path $file -Parent) -eq $bootstrap -and [IO.Path]::GetFileName($file) -match '^(ZyroFools-\d+\.\d+\.\d+(?:\.\d+)?-Update\.zip|release\.json)$'){Safe-Path $file;if(Test-Path $file){Remove-Item $file -Force}}}
 $cache=Join-Path ([Environment]::GetFolderPath('ApplicationData')) 'ZyroFools\UpdatesV2'
 foreach($file in @($j.archive,$j.envelope)){if((Split-Path $file -Parent) -eq $cache -and [IO.Path]::GetFileName($file) -match '^ZyroFools-\d+\.\d+\.\d+(?:\.\d+)?-[a-f0-9]{16}-Update\.zip(?:\.json)?$'){Safe-Path $file;if(Test-Path $file){Remove-Item $file -Force}}}
 Remove-Item $journalFile -Force;Status 'Atualização confirmada; arquivos temporários removidos.' 100
}
try{
 Safe-Path $Target;Safe-Path $work;Safe-Path $rollback;Safe-Path $stage
 if(-not(Test-Path (Join-Path $Target 'ZyroFools.exe'))){throw 'Zyro Fools não encontrado. Informe a pasta do painel.'}
 New-Item -ItemType Directory -Path $work -Force|Out-Null
 Lock-Update
 if(-not $Headless){
 Add-Type -AssemblyName PresentationFramework
 [xml]$x='<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="Zyro Fools · Atualizações" Width="620" Height="420" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" Background="#10060C" Foreground="#FFF0F5" FontFamily="Segoe UI"><Grid Margin="30"><Grid.RowDefinitions><RowDefinition Height="72"/><RowDefinition Height="*"/><RowDefinition Height="44"/></Grid.RowDefinitions><StackPanel><TextBlock FontSize="28" FontWeight="Bold"><Run Text="ZYRO"/><Run Text=" FOOLS" Foreground="#FF2254"/></TextBlock><TextBlock Text="SEU WORKSPACE, SEMPRE EM DIA." FontSize="10" Foreground="#C496A8" Margin="0,6,0,0"/></StackPanel><Border Grid.Row="1" BorderBrush="#742038" BorderThickness="1" CornerRadius="12" Background="#1C0B13" Padding="22"><StackPanel><TextBlock Text="Um novo movimento." FontSize="25" FontWeight="SemiBold"/><TextBlock Name="Status" MaxHeight="48" TextTrimming="CharacterEllipsis" Text="Preparando a atualização…" Margin="0,18,0,20" TextWrapping="Wrap" Foreground="#DFC0CC"/><ProgressBar Name="Progress" Height="8" Minimum="0" Maximum="100" Foreground="#FF2254" Background="#3B1322"/><TextBlock Text="Sua licença e configurações são preservadas." FontSize="11" Foreground="#AA7C8D" Margin="0,18,0,0"/></StackPanel></Border><Button Name="Recover" Grid.Row="2" Content="Restaurar versão anterior" Visibility="Collapsed" HorizontalAlignment="Right" Padding="18,8" Background="#5A1026" Foreground="#FFF0F5" BorderBrush="#FF2254"/></Grid></Window>'
 $reader=New-Object Xml.XmlNodeReader $x;$script:window=[Windows.Markup.XamlReader]::Load($reader);$script:label=$script:window.FindName('Status');$script:bar=$script:window.FindName('Progress');$recover=$script:window.FindName('Recover')
 $icon=Join-Path $PSScriptRoot 'icon.ico';if(Test-Path $icon){$script:window.Icon=[Windows.Media.Imaging.BitmapFrame]::Create([Uri]::new($icon))}
 $timer=New-Object Windows.Threading.DispatcherTimer;$timer.Interval=[TimeSpan]::FromSeconds(1);$timer.Add_Tick({if(-not $script:applying -and $script:bar.Value -eq 100 -and -not(Test-Path $journalFile)){$timer.Stop();$script:window.Close()}});$timer.Start()
 $script:window.Add_Closing({param($s,$e)if($script:applying){$e.Cancel=$true}})
 $recover.Add_Click({$script:applying=$true;try{Restore;Restart-Panel;$recover.Visibility='Collapsed'}catch{Status $_.Exception.Message 0}finally{$script:applying=$false}})
 $script:window.Add_ContentRendered({$script:applying=$true;try{if($Action -eq 'Apply'){Apply}else{Restore;Restart-Panel};$script:applying=$false;if(Test-Path $journalFile){$recover.Visibility='Visible';Status 'Painel atualizado. O backup será removido após confirmar a abertura.' 100}else{$script:window.Close()}}catch{Status $_.Exception.Message 0;if(Test-Path $journalFile){$recover.Visibility='Visible'}}finally{$script:applying=$false}})
 [void]$script:window.ShowDialog()
 }else{switch($Action){'Apply'{Apply}'Confirm'{Confirm}'Rollback'{Restore;Restart-Panel}}}
}catch{if(Test-Path (Split-Path $log)){Log $_.Exception.Message};if($Headless){[Console]::Error.WriteLine($_.Exception.Message)}else{Add-Type -AssemblyName PresentationFramework;[Windows.MessageBox]::Show($_.Exception.Message,'Atualizações · Zyro Fools')|Out-Null};exit 1}finally{if($mutex){$mutex.Dispose()}}
