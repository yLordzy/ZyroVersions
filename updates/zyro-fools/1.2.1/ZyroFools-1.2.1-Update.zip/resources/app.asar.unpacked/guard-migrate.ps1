﻿# Migration is limited to the exact two legacy ZyroGuard binaries supplied by the owner.
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$Known = @('41EC8C9C88897807CB3FC2509A374ECF9CDB53DF98BF0B8047923D191ACA15E6','327C4CD5565ECDCBF31095BE8204445FE3A2C45D751C5AAA9E43BFC9CFFBDFEA')
$Messages = New-Object System.Collections.Generic.List[string]
function Is-KnownGuard([string]$File) {
    if (-not $File -or -not (Test-Path -LiteralPath $File -PathType Leaf)) { return $false }
    return $Known -contains (Get-FileHash -LiteralPath $File -Algorithm SHA256).Hash
}
foreach ($Process in @(Get-Process -Name 'ZyroGuard','ZyroGuard-new' -ErrorAction SilentlyContinue)) {
    try {
        if (Is-KnownGuard $Process.MainModule.FileName) { $Process.Kill(); $Process.WaitForExit(3000) | Out-Null }
        else { $Messages.Add('Outro ZyroGuard foi detectado. Confira e encerre o guard antigo antes de usar esta versão.') }
    } catch { $Messages.Add('Não foi possível encerrar o guard antigo. Encerre-o manualmente antes de usar esta versão.') }
}
try {
    $Run = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Run', $true)
    if ($Run) {
        try {
            $Value = [string]$Run.GetValue('ZyroGuard')
            $File = [Environment]::ExpandEnvironmentVariables($Value).Trim().Trim('"')
            if (Is-KnownGuard $File) { $Run.DeleteValue('ZyroGuard', $false) }
            elseif ($Value) { $Messages.Add('Confira a inicialização do ZyroGuard antigo nas configurações do Windows.') }
        } finally { $Run.Close() }
    }
} catch { $Messages.Add('Confira a inicialização do guard antigo nas configurações do Windows.') }
ConvertTo-Json -InputObject @($Messages.ToArray()) -Compress
