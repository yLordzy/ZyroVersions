﻿param([Parameter(Mandatory=$true)][ValidateSet('Protect','Unprotect')][string]$Mode)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
try {
    Add-Type -AssemblyName System.Security
    $InputBytes = [Convert]::FromBase64String([Console]::In.ReadToEnd().Trim())
    $Entropy = [Text.Encoding]::UTF8.GetBytes('ZyroFools.Guard.v1')
    $Scope = [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    if ($Mode -eq 'Protect') {
        $OutputBytes = [System.Security.Cryptography.ProtectedData]::Protect($InputBytes, $Entropy, $Scope)
    } else {
        $OutputBytes = [System.Security.Cryptography.ProtectedData]::Unprotect($InputBytes, $Entropy, $Scope)
    }
    [Console]::Out.Write([Convert]::ToBase64String($OutputBytes))
} catch {
    [Console]::Error.WriteLine('Protecao Windows indisponivel.')
    exit 1
}
